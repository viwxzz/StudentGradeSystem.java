import java.util.Scanner;

public class StudentGradeSystem {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Student Name: ");
        String name = sc.nextLine();

        System.out.print("Enter Marks in Subject 1: ");
        int m1 = sc.nextInt();

        System.out.print("Enter Marks in Subject 2: ");
        int m2 = sc.nextInt();

        System.out.print("Enter Marks in Subject 3: ");
        int m3 = sc.nextInt();

        double average = (m1 + m2 + m3) / 3.0;

        char grade;

        if (average >= 80)
            grade = 'A';
        else if (average >= 60)
            grade = 'B';
        else if (average >= 40)
            grade = 'C';
        else
            grade = 'F';

        System.out.println("\n----- REPORT -----");
        System.out.println("Name: " + name);
        System.out.println("Average: " + average);
        System.out.println("Grade: " + grade);

        sc.close();
    }
}